#!/usr/bin/env python3
"""Build GBIF rodent occurrence dataset with provenance."""

from __future__ import annotations


def main() -> int:
    raise SystemExit("Not implemented: requires source-audited real data before analysis.")


if __name__ == "__main__":
    raise SystemExit(main())
